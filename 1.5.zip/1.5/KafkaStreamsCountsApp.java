package com.example;

import java.util.Properties;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.utils.Bytes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Materialized;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.kafka.streams.state.KeyValueStore;

public final class KafkaStreamsCountsApp {

    static final String SOURCE_TOPIC = "input-topic";
    static final String TARGET_TOPIC = "output-topic";
    static final String STATE_STORE = "counts-store";
    static final String STREAMS_APP_NAME = "counts-app";
    
    public static KafkaStreams startStreamsApp() {

        Properties configurations = new Properties();
        configurations.put(StreamsConfig.APPLICATION_ID_CONFIG, STREAMS_APP_NAME);
        configurations.put(StreamsConfig.APPLICATION_SERVER_CONFIG, "localhost:8080");
        configurations.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        configurations.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        configurations.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());

        StreamsBuilder builder = new StreamsBuilder();
        KStream<String, String> source = builder.stream(SOURCE_TOPIC);

        Materialized<String, Long, KeyValueStore<Bytes, byte[]>> store = Materialized.<String, Long, KeyValueStore<Bytes, byte[]>>as(STATE_STORE).withKeySerde(Serdes.String())
                .withValueSerde(Serdes.Long());

        source.groupByKey().count(store)
                          .toStream()
                          .to(TARGET_TOPIC, Produced.with(Serdes.String(), Serdes.Long()));

        KafkaStreams app = new KafkaStreams(builder.build(), configurations);
        app.start();
        System.out.println("Started kafka streams application");

        return app;

    }

}
