package com.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.state.QueryableStoreTypes;
import org.apache.kafka.streams.state.ReadOnlyKeyValueStore;

@Path("counts")
public final class CountsAPI {

    @GET
    public Response all() throws Exception {
        System.out.println("Querying all data from state store");

        Response response = null;
        try {
            KafkaStreams ks = AppState.getInstance().getKafkaStreams();

            ReadOnlyKeyValueStore<String, Long> countsStore = ks
                .store(KafkaStreamsCountsApp.STATE_STORE,
                        QueryableStoreTypes.<String, Long>keyValueStore());

            
            StringBuffer resp = new StringBuffer();
            countsStore.all().forEachRemaining(kv -> resp.append(kv.key + "=" + kv.value + "\n"));

            System.out.println("State store data\n" + resp.toString());
            response = Response.ok(resp.toString()).build();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return response;
    }

    @GET
    @Path("{key}")
    public Response getMachineMetric(@PathParam("key") String key) {
        
        System.out.println("Querying value for key " + key + " from state store");

        KafkaStreams ks = AppState.getInstance().getKafkaStreams();

        ReadOnlyKeyValueStore<String, Long> countsStore = ks
                .store(KafkaStreamsCountsApp.STATE_STORE,
                        QueryableStoreTypes.<String, Long>keyValueStore());

        Long count = countsStore.get(key);

        System.out.println("State store data for key " + key + " is " + count);
        
        String response = key+"="+count;
        return Response.ok(response).build();
    }
}
