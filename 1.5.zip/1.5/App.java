package com.example;

import java.net.URI;
import javax.ws.rs.core.UriBuilder;
import org.glassfish.grizzly.http.server.HttpServer;
import org.glassfish.jersey.grizzly2.httpserver.GrizzlyHttpServerFactory;
import org.glassfish.jersey.server.ResourceConfig;
import org.apache.kafka.streams.KafkaStreams;

public class App {

    public static void main(String[] args) throws Exception {

        ResourceConfig config = new ResourceConfig(CountsAPI.class);

        URI url = UriBuilder.fromUri("http://0.0.0.0/").port(Integer.parseInt("8080")).build();
        HttpServer server = GrizzlyHttpServerFactory.createHttpServer(url, config);
        server.start();

        System.out.println("State store REST server started at - " + url);

        AppState.getInstance().hostPortInfo("localhost", "8080");

        KafkaStreams stream = KafkaStreamsCountsApp.startStreamsApp();

        AppState.getInstance().streams(stream);

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("Shutdown hook called. Exiting application");
                try {
                    stream.close();
                    server.shutdownNow();
                    System.out.println("shutdown complete");
                } catch (Exception ex) {
                    System.out.println("shutdown exception " + ex.getMessage());
                }

            }
        }));
    }

}
