package com.example;

import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.state.HostInfo;

public final class AppState {
    private HostInfo hostInfo;
    private KafkaStreams kafkaStreams;
    
    private AppState() {
    }
    
    private static AppState INSTANCE = new AppState();
    
    public static AppState getInstance(){
        return INSTANCE;
    }
    
    public AppState hostPortInfo(String host, String port){
        hostInfo = new HostInfo(host, Integer.parseInt(port));
        return this;
    }
    
    public AppState streams(KafkaStreams ks){
        kafkaStreams = ks;
        return this;
    }
    
    public HostInfo getHostPortInfo() {
        return this.hostInfo;
    }
    
    public KafkaStreams getKafkaStreams(){
        return this.kafkaStreams;
    }
 
}
